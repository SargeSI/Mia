# STT Troubleshooting — дополнение к Gemini Vision багтрекингу

## Когда применяется

Расшифровка голосовых сообщений не работает (таймауты, 403, 429, 401).

## Быстрая диагностика

```bash
# 1. Проверить текущий STT-провайдер
hermes config show | grep -A5 stt:

# 2. Проверить ключ в .env (если провайдер = groq)
grep GROQ_API_KEY /home/mia/Mia/.env | wc -c

# 3. Проверить ключ в .env (если провайдер = openai)
grep OPENAI_API_KEY /home/mia/Mia/.env | wc -c
```

## Матрица ошибок STT

| Провайдер | Ошибка | Причина | Решение |
|-----------|--------|---------|---------|
| **Groq** | 403 Forbidden | Гео-блок: Россия не поддерживается (напрямую) | VPN |
| **Groq** через VPN | 403 error code: 1010 | Cloudflare WAF банит IP VPN-сервера | Другой VPN-сервер с чистым IP |
| **Groq** | 429 Rate Limited | Исчерпан лимит (14 400/день, 30/мин) | Ждать сброса |
| **OpenAI Whisper** | 429 insufficient_quota | Баланс $0 — нужна предоплата | Пополнить баланс OpenAI |
| **OpenAI Whisper** | 401 invalid_api_key | Невалидный ключ | Создать новый в platform.openai.com |
| **OpenAI Whisper** | unsupported_country | Гео-блок РФ | VPN |
| Любой | Таймаут | Сеть/VPN не работает | Проверить `awg show`, маршруты |

## Конфигурация STT

```yaml
# config.yaml
stt:
  provider: groq        # или openai
  enabled: true
  # модель определяется провайдером автоматически (whisper-1)
```

Hermes читает ключи из `/home/mia/Mia/.env` через `load_env()`.
**НИКОГДА** не прописывать ключи в systemd override (`/etc/systemd/system/hermes-gateway.service.d/env.conf`).

## Как Hermes читает .env

- `hermes_cli/config.py::load_env()` — читает `.env` в словарь
- `agent/credential_pool.py::_get_env_prefer_dotenv(key)` — берёт из `.env`, fallback на `os.environ`
- STT-провайдеры (openai, groq) используют `os.environ` — НО Hermes загружает `.env` в `os.environ` при старте
- **Systemd `EnvironmentFile` НЕ нужен** — Hermes делает это сам

## Тестирование Groq API напрямую

```bash
# Через VPN
sudo awk -F= '/^GROQ_API_KEY/{print $2}' /home/mia/Mia/.env | head -1 | \
  xargs -I {} curl -s --max-time 10 -H "Authorization: Bearer *** \
  "https://api.groq.com/openai/v1/models"

# Без VPN (убрать маршрут Cloudflare)
sudo ip route del 104.18.0.0/20 dev tg-dubai
# ... тест ...
sudo ip route add 104.18.0.0/20 dev tg-dubai
```

## Тестирование OpenAI Whisper API напрямую

```bash
sudo awk -F= '/^OPENAI_API_KEY/{print $2}' /home/mia/Mia/.env | head -1 | \
  xargs -I {} curl -s --max-time 10 -H "Authorization: Bearer *** \
  "https://api.openai.com/v1/models" | python3 -c "import sys,json; d=json.load(sys.stdin); print('OK' if 'data' in d else d.get('error',{}).get('message','UNKNOWN'))"
```
