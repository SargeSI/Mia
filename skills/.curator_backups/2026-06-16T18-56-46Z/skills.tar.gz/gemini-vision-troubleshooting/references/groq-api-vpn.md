# Groq API — VPN Routing

**Проблема:** Groq API (`api.groq.com`) таймаутит — трафик не идёт через VPN.

**Причина:** Тот же паттерн, что с Gemini. Groq API хостится на Cloudflare (104.18.0.0/20), который не добавлен в AllowedIPs AmneziaWG.

**Решение:** добавить `104.18.0.0/20` в `/etc/wireguard/tg-dubai.conf` → `AllowedIPs`:

```bash
# Добавить диапазон
sudo sed -i 's/AllowedIPs = /AllowedIPs = 104.18.0.0\/20, /' /etc/wireguard/tg-dubai.conf

# Перезапустить туннель
sudo awg-quick down /etc/wireguard/tg-dubai.conf
sudo awg-quick up /etc/wireguard/tg-dubai.conf

# Проверить handshake
sudo awg show | grep handshake
```

**Проверка API:**
```bash
# Т.к. ключ содержит спецсимволы, использовать awk + xargs:
sudo awk -F= '/^GROQ_API_KEY/{print $2}' /home/mia/Mia/.env | head -1 | xargs -I {} curl -s --max-time 10 -H 'Authorization: Bearer *** 'https://api.groq.com/openai/v1/models'
```

**Диагностика:** если ответ `Forbidden` → ключ невалидный. Если таймаут → не добавлен в VPN.

**Дата:** 4 июня 2026
