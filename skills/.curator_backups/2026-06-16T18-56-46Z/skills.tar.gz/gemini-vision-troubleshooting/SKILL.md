---
name: gemini-vision-troubleshooting
created_by: "user"
description: "Диагностика проблем с Gemini Vision API: история баг-трекинга, пройденные гипотезы, корневая причина, решение."
---

# Gemini Vision — диагностика проблем

**Дата инцидента:** 3 июня 2026
**Симптом:** Gemini Vision API не работает (таймауты, 403, 429)
**Корневая причина:** раздельные квоты у gemini-2.0-flash и gemini-2.5-flash

## Корневая причина

**Gemini 2.0 Flash и Gemini 2.5 Flash имеют РАЗДЕЛЬНЫЕ квоты.** Бесплатный тир: RPM=15/мин, RPD=1 500/день на КАЖДУЮ модель отдельно.

## Пройденные гипотезы (все ❌)

1. Google банит IP VPN-сервера
2. Сеть/VPN не работает (AmneziaWG теряет handshake после ребута)
3. Ключ не работает / скомпрометирован
4. Суточная квота исчерпана (RPD)
5. DPI блокирует Google API

## Решение

```bash
hermes config set auxiliary.vision.model gemini-2.5-flash
sudo systemctl restart hermes-gateway
```

## Быстрая проверка

```bash
# 1. VPN
sudo awg show  # должен быть "latest handshake: N seconds ago"

# 2. Gemini
GOOGLE_KEY=$(grep '^GOOGLE_API_KEY=*** /home/mia/Mia/.env | head -1 | cut -d= -f2-)
curl -s --max-time 15 \
  "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${GOOGLE_KEY}" \
  -H "Content-Type: application/json" \
  -d '{"contents":[{"parts":[{"text":"Say ok"}]}]}'
```

## Коды ошибок

- 200 → работает
- 429 → квота (попробовать другую модель)
- 403 → проблема с ключом
- Таймаут → проблема с VPN (проверить `awg show`)

## AmneziaWG

- Это НЕ WireGuard. Использовать `awg`, не `wg`.
- Конфиг: `/etc/wireguard/tg-dubai.conf`
- Сервис: `awg-tunnel.service` (oneshot)
- После ребута: `sudo awg-quick down/up /etc/wireguard/tg-dubai.conf`

## Связанные файлы

- `/home/mia/Mia/config.yaml` — секция `auxiliary.vision`
- `/etc/wireguard/tg-dubai.conf` — конфиг AmneziaWG
- `references/gemini-vision-vpn.md` — Google-диапазоны
- `references/groq-api-vpn.md` — Groq API (тот же паттерн)
- `created_by: "user"` — curator will NOT archive this skill.
