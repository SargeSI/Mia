---
name: retro-hardware-research
description: Research and evaluate used/retro gaming hardware before purchase — identify model variants, known defects, modding paths, fair pricing, and inspection checklist. Applies to any retro console, handheld, or gaming hardware.
---

# Retro Hardware Research

Systematic pre-purchase research for used/retro gaming hardware. Helps answer "do I need it", "which variant", and "what to check" before buying.

## Triggers

- "стоит ли купить [console]"
- "какую версию [console] выбрать"
- "чем отличается [model A] от [model B]"
- Any retro console/handheld evaluation before purchase

## Methodology (Cold Mode — Advise, Don't Execute)

### Phase 1: Need Analysis
- Ask: **what do you want to play on it?** This determines whether the hardware is right at all
- Identify alternatives (modern clones, emulation, other consoles)
- The native library is the decisive factor — if they want those specific games, original hardware wins

### Phase 2: Model/Variant Identification
- Research ALL model variants (revisions, regions, special editions)
- Key differentiators: screen technology, internal storage, port types, SoC revisions, known defects
- Use authoritative sources: consolemods.org, psdevwiki, reddit r/<console>hacks, GBAtemp
- **Pitfall:** SKU codes from wikis may not match what's printed on the device sticker. Verify with real photos on eBay before claiming "the sticker says X"

### Phase 3: Defect Research
- Identify model-specific failure modes and their prevalence
- Distinguish repairable defects from unfixable ones
- Prioritize: unfixable defects (e.g., OLED burn-in) > difficult repairs > easy repairs > cosmetics

### Phase 4: Modding & Upgrade Path
- CFW/homebrew status: which firmware versions are hackable?
- Storage expansion options (SD adapters, internal mods)
- Port upgrades (USB-C mods, battery replacements)
- Part availability and cost for common repairs

### Phase 5: Market Evaluation
- Check current market prices on Avito, eBay, local marketplaces
- Identify fair price range for each variant
- Flag overpriced listings vs bargains vs potential scams (franken-consoles, aftermarket shells)

### Phase 6: Inspection Checklist
- For in-person inspection: specific tests to run, what to look for visually
- For remote purchase (photos only): what to ask seller to photograph, red flags in photos
- Specific screen test patterns (which colors/backgrounds reveal which defects)

## Reference Files

- `references/ps-vita-buying-guide.md` — PS Vita Fat (PCH-1000) complete buying guide with model matrix, defect catalog, modding paths, and market data
