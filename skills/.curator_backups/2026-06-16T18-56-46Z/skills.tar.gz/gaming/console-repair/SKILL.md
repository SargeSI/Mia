---
name: console-repair
description: Diagnose and repair gaming consoles — PS3 YLOD, NEC/TOKIN capacitor replacement, power supply issues. For use when the user reports console failure symptoms and needs diagnostic + repair procedure.
---

# Console Repair

Diagnose and repair gaming consoles. Covers common failure modes, part sourcing, and step-by-step repair instructions.

## Triggers

- Console failure symptoms: beeping, flashing lights, no power, YLOD, RLOD
- "моя [console] не включается / пищит / мигает"
- User asks for repair plan or part list

## Workflow

### Phase 1: Diagnosis
- Identify exact model number (CECHxx for PS3, PCH-xxxx for Vita, etc.)
- Match symptoms to known failure modes
- Distinguish between power supply, capacitor, and BGA issues based on behavior patterns
- **Key differentiators:** cold-start behavior (capacitors), load-dependent failures (PSU), progressive worsening (caps), sudden death (BGA)

### Phase 2: Repair Plan
- Confirm required parts with exact specifications
- Source parts locally (list specific stores and part numbers when possible)
- List required tools
- Assess difficulty and whether DIY or professional repair is appropriate

### Phase 3: Repair Instructions
- Disassembly steps
- Component replacement procedure with photos/links to references
- Reassembly and testing

## Reference Files

- `references/ps3-nec-tokin-replacement.md` — PS3 Fat NEC/TOKIN capacitor replacement (YLOD fix), CECHH08-specific, parts in Moscow
