---
name: hf-image-gen
created_by: "user"
description: "Generate photorealistic images via Hugging Face FLUX.1 — use for portraits, engineering concepts, technical illustrations. Free serverless tier, requires HF_TOKEN."
category: creative
triggers:
  - generate image
  - generate picture
  - draw me
  - нарисуй
  - сгенерируй картинку
  - портрет
  - концепт
  - рендер
  - selfie
  - селфи
---

# HF Image Generation (FLUX.1)

Generate images via Hugging Face serverless Inference API using FLUX.1-schnell (fast, 4 steps) or FLUX.1-dev (higher quality).

## Prerequisites

- HF_TOKEN in `/home/mia/Mia/.env` — Read-only fine-grained token with "Make calls to Inference Providers" permission
- Uses `https://router.huggingface.co/hf-inference/models/{model}` — NOT `api-inference.huggingface.co` (blocked by DPI)

## Script

Run `skills/creative/hf-image-gen/scripts/generate.py`:

```bash
HERMES_HOME=/home/mia/Mia python3 skills/creative/hf-image-gen/scripts/generate.py "prompt" [--model MODEL] [--output PATH]
```

Default: `black-forest-labs/FLUX.1-schnell`

## Model Selection

| Use Case | Model | Why |
|----------|-------|-----|
| Portraits, people | FLUX.1-schnell | Fast, great skin tones |
| Engineering concepts | FLUX.1-schnell | 4 steps, quick iteration |
| Technical illustrations | FLUX.1-dev | More detail, cleaner lines |

## FLUX Prompt Engineering — Known Failure Modes

FLUX.1-schnell is powerful but has specific failure modes. **Always add these guards for portrait prompts:**

| Problem | Observed | Fix |
|---------|----------|-----|
| Ethnicity mismatch (Asian instead of Caucasian) | Mia rendered with East Asian features | Add `Caucasian, Slavic features, European facial features` |
| Merged/fused hands | Both hands rendered as one blob | Add `detailed fingers, anatomically correct hands, hands at sides` |
| Oversized accessories (watch = rucksack) | Mechanical watch fills half the torso | Use `delicate mechanical watch with thin metal band on left wrist only` |
| Accessory misplacement | Watch on shoulder strap instead of wrist | Explicit body-part: `on left wrist only`, `at hip`, `in right hand` |
| Too-clean cyberpunk | Looks like indoor photo, no cyberpunk aesthetic | Add `chrome reflections, neon-lit rain, holographic HUD, cybernetic temple implant, blade runner aesthetic, dark alley with reflections on wet surfaces` |
| Accessory hyperbolization | Small detail (watch, glasses) rendered huge | Use `delicate`, `thin`, `compact`, precise body location; FLUX inflates object-words without restraint adjectives |

## Mia's Portrait — Source of Truth

**SOUL.md (section "Внешность") is the canonical source.** Read it, then convert to FLUX prompt using the guard table above. Do NOT hardcode Mia's appearance here — appearance changes go in SOUL.md only.

## Prompts for Non-Mia Subjects

For engineering concepts: add `technical drawing style` or `isometric view`.
For product renders: add `photorealistic, studio lighting`.
For futuristic: add `cyberpunk-meets-realistic`.

## URL

- Correct: `https://router.huggingface.co/hf-inference/models/{model}`
- Wrong: `https://api-inference.huggingface.co/...` — DPI blocks DNS
- Wrong: `https://router.huggingface.co/{model}` — missing `/hf-inference/models/` path

## Pitfalls

- 401 → check token length (must be 37 chars)
- 403 → "Inference provider not available" → HF disabled free tier for that model
- 503 → model cold-start, wait 30s and retry
- 429 → rate limited, wait and retry
- Token must have "Make calls to Inference Providers" permission
- SDXL Base is DEPRECATED on HF — use FLUX instead
- **Curator protection:** `created_by: "user"` — curator will NOT archive this skill

## File Safety

⚠️ Before writing to any existing file, ALWAYS `read_file` first. Prefer `patch` for targeted edits.
